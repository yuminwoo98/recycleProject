# recycleProject
모블 분리수거 팀 프로젝트

1. 얼굴인식 - 
faceDetect.py
2. 객체인식- 
objectDetect.py
3. 이미지 전송 - 
sendImg.py
4. 로봇 팔 제어 - 
robotArm.py
5. 웹 페이지 - 
(master) webRecycle folder
